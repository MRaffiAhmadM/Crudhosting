@extends('layouts.app')

@section('body')
    <h1>Ini Halaman Depan</h1>
@endsection